import * as THREE from 'three';
import { World } from './world.js';
import { Player } from './player.js';

// --- Scene Setup ---
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87CEEB); // Minecraft Sky Color
scene.fog = new THREE.Fog(0x87CEEB, 20, 50);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderer = new THREE.WebGLRenderer({ antialias: false }); // False for crisp pixels
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(window.devicePixelRatio);
document.body.appendChild(renderer.domElement);

// --- Lighting ---
const ambientLight = new THREE.AmbientLight(0xcccccc, 0.6);
scene.add(ambientLight);
const dirLight = new THREE.DirectionalLight(0xffffff, 0.6);
dirLight.position.set(10, 20, 10);
scene.add(dirLight);

// --- Game Systems ---
const world = new World(scene);
const player = new Player(camera, document.body, world, scene);

// --- UI Logic ---
const instructions = document.getElementById('instructions');
player.controls.addEventListener('lock', () => { instructions.style.display = 'none'; });
player.controls.addEventListener('unlock', () => { instructions.style.display = 'block'; });

// --- Game Loop ---
const clock = new THREE.Clock();

function animate() {
    requestAnimationFrame(animate);
    const delta = Math.min(clock.getDelta(), 0.1); // Cap delta to prevent physics explosions on lag
    
    player.update(delta);
    
    renderer.render(scene, camera);
}

// --- Resize Handler ---
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

animate();
