import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

export class Player {
    constructor(camera, domElement, world, scene) {
        this.camera = camera;
        this.world = world;
        this.scene = scene;
        this.controls = new PointerLockControls(camera, domElement);
        
        // Java Edition style Physics Constants
        this.gravity = 32.0; 
        this.jumpSpeed = 8.5;
        this.movementSpeed = 4.3; 
        
        this.velocity = new THREE.Vector3();
        this.direction = new THREE.Vector3();
        this.position = this.camera.position;
        this.position.set(0, 15, 0); // Start in sky to fall down
        
        this.isGrounded = false;
        
        // Raycaster for breaking/placing
        this.raycaster = new THREE.Raycaster();
        this.raycaster.near = 0;
        this.raycaster.far = 5; // Minecraft reach is roughly 4.5 blocks
        
        // Highlight box for targeted block
        const boxGeo = new THREE.BoxGeometry(1.01, 1.01, 1.01);
        const boxMat = new THREE.LineBasicMaterial({ color: 0x000000, linewidth: 2 });
        const boxEdges = new THREE.EdgesGeometry(boxGeo);
        this.selectionBox = new THREE.LineSegments(boxEdges, boxMat);
        this.selectionBox.visible = false;
        this.scene.add(this.selectionBox);

        this.keys = { forward: false, backward: false, left: false, right: false, space: false };
        this.initListeners();
    }

    initListeners() {
        document.addEventListener('keydown', (e) => this.onKey(e.code, true));
        document.addEventListener('keyup', (e) => this.onKey(e.code, false));
        
        document.addEventListener('mousedown', (e) => {
            if (!this.controls.isLocked) {
                this.controls.lock();
                return;
            }
            if (e.button === 0) this.interactBlock('break');
            if (e.button === 2) this.interactBlock('place');
        });
    }

    onKey(code, isDown) {
        switch(code) {
            case 'KeyW': this.keys.forward = isDown; break;
            case 'KeyS': this.keys.backward = isDown; break;
            case 'KeyA': this.keys.left = isDown; break;
            case 'KeyD': this.keys.right = isDown; break;
            case 'Space': 
                if (isDown && this.isGrounded) {
                    this.velocity.y = this.jumpSpeed;
                    this.isGrounded = false;
                }
                break;
        }
    }
    
    interactBlock(action) {
        // Setup raycaster from camera center
        this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
        
        // We do a discrete step raycast for block precision (simplified Voxel Raycast)
        let ray = this.raycaster.ray;
        let p = ray.origin.clone();
        let d = ray.direction.clone().normalize().multiplyScalar(0.1); // Step size
        
        for (let i = 0; i < 50; i++) {
            p.add(d);
            let bx = Math.round(p.x);
            let by = Math.round(p.y);
            let bz = Math.round(p.z);
            
            if (this.world.getBlock(bx, by, bz)) {
                if (action === 'break') {
                    this.world.setBlock(bx, by, bz, 0);
                } else if (action === 'place') {
                    // Step back one unit in the ray to find the empty space
                    p.sub(d);
                    let px = Math.round(p.x);
                    let py = Math.round(p.y);
                    let pz = Math.round(p.z);
                    
                    // Prevent placing block inside the player
                    if (py !== Math.floor(this.position.y) && py !== Math.floor(this.position.y - 1)) {
                         this.world.setBlock(px, py, pz, 1);
                    }
                }
                return;
            }
        }
    }
    
    updateSelectionBox() {
        this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
        let ray = this.raycaster.ray;
        let p = ray.origin.clone();
        let d = ray.direction.clone().normalize().multiplyScalar(0.1);
        
        this.selectionBox.visible = false;
        
        for (let i = 0; i < 50; i++) {
            p.add(d);
            let bx = Math.round(p.x);
            let by = Math.round(p.y);
            let bz = Math.round(p.z);
            
            if (this.world.getBlock(bx, by, bz)) {
                this.selectionBox.position.set(bx, by, bz);
                this.selectionBox.visible = true;
                break;
            }
        }
    }

    update(delta) {
        if (!this.controls.isLocked) return;
        
        this.updateSelectionBox();

        // Apply Gravity
        this.velocity.y -= this.gravity * delta;

        // Calculate input movement direction
        this.direction.z = Number(this.keys.forward) - Number(this.keys.backward);
        this.direction.x = Number(this.keys.right) - Number(this.keys.left);
        this.direction.normalize(); // Ensure diagonal movement isn't faster

        // Apply acceleration (Simplified for demo, real Minecraft has acceleration curves)
        let frameSpeed = this.movementSpeed * delta * 50;
        
        if (this.keys.forward || this.keys.backward) this.velocity.z -= this.direction.z * frameSpeed;
        if (this.keys.left || this.keys.right) this.velocity.x -= this.direction.x * frameSpeed;

        // Friction / Deceleration (0.91 air resistance equivalent)
        this.velocity.x *= 0.8;
        this.velocity.z *= 0.8;
        
        // AABB Collision (Simplified discrete checking)
        // X-Axis Collision
        let nextX = this.position.x - (this.velocity.x * delta);
        if (this.checkCollision(nextX, this.position.y, this.position.z)) {
            this.velocity.x = 0;
        } else {
            this.controls.moveRight(-this.velocity.x * delta);
        }

        // Z-Axis Collision
        let nextZ = this.position.z - (this.velocity.z * delta);
        if (this.checkCollision(this.position.x, this.position.y, nextZ)) {
            this.velocity.z = 0;
        } else {
            this.controls.moveForward(-this.velocity.z * delta);
        }

        // Y-Axis Collision (Floor and Ceiling)
        let nextY = this.position.y + (this.velocity.y * delta);
        if (this.velocity.y < 0 && this.checkCollision(this.position.x, nextY - 1.5, this.position.z)) {
            // Hit Floor
            this.velocity.y = 0;
            this.isGrounded = true;
            this.position.y = Math.floor(nextY - 1.5) + 2.5; // Snap to ground
        } else if (this.velocity.y > 0 && this.checkCollision(this.position.x, nextY + 0.5, this.position.z)) {
            // Hit Ceiling
            this.velocity.y = 0;
        } else {
            this.position.y += this.velocity.y * delta;
            this.isGrounded = false;
        }
    }
    
    checkCollision(x, y, z) {
        // Player bounding box (0.6 width, 1.8 height)
        const width = 0.3; // Half-width
        
        // Check the 8 corners of the bounding box against the voxel grid
        const corners = [
            {x: x - width, y: y, z: z - width},
            {x: x + width, y: y, z: z - width},
            {x: x - width, y: y, z: z + width},
            {x: x + width, y: y, z: z + width},
            {x: x - width, y: y - 1.5, z: z - width},
            {x: x + width, y: y - 1.5, z: z - width},
            {x: x - width, y: y - 1.5, z: z + width},
            {x: x + width, y: y - 1.5, z: z + width}
        ];
        
        for (let corner of corners) {
            if (this.world.getBlock(Math.round(corner.x), Math.round(corner.y), Math.round(corner.z))) {
                return true;
            }
        }
        return false;
    }
}
