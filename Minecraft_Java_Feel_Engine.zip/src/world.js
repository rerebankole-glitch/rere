import * as THREE from 'three';

export class World {
    constructor(scene) {
        this.scene = scene;
        this.blocks = new Map(); // Key: 'x,y,z', Value: blockId
        this.chunkSize = 32;
        
        // Use InstancedMesh for high-performance block rendering
        // In a full production build, you'd upgrade this to a custom BufferGeometry with Greedy Meshing
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        
        // Create a pixelated texture material
        const canvas = document.createElement('canvas');
        canvas.width = 16; canvas.height = 16;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#55aa55'; ctx.fillRect(0,0,16,16); // Grass top
        ctx.fillStyle = '#8B4513'; ctx.fillRect(0,4,16,12); // Dirt side
        const texture = new THREE.CanvasTexture(canvas);
        texture.magFilter = THREE.NearestFilter; // Crisp Minecraft look
        texture.minFilter = THREE.NearestFilter;
        
        const material = new THREE.MeshLambertMaterial({ map: texture });
        
        // Allocate space for up to 20,000 blocks in this demo chunk
        this.instancedMesh = new THREE.InstancedMesh(geometry, material, 20000);
        this.instancedMesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        this.scene.add(this.instancedMesh);
        
        this.generateTerrain();
    }

    generateTerrain() {
        let count = 0;
        const matrix = new THREE.Matrix4();
        
        // Simple rolling hills terrain generation
        for (let x = -this.chunkSize/2; x < this.chunkSize/2; x++) {
            for (let z = -this.chunkSize/2; z < this.chunkSize/2; z++) {
                // Pseudo-noise for height
                const y = Math.floor(Math.sin(x / 5) * 2 + Math.cos(z / 4) * 2);
                
                // Set solid ground
                for (let depth = y; depth >= y - 3; depth--) {
                    this.setBlock(x, depth, z, 1, false);
                    matrix.setPosition(x, depth, z);
                    this.instancedMesh.setMatrixAt(count++, matrix);
                }
            }
        }
        this.instancedMesh.count = count;
        this.instancedMesh.instanceMatrix.needsUpdate = true;
    }

    setBlock(x, y, z, id, updateMesh = true) {
        const key = `${Math.round(x)},${Math.round(y)},${Math.round(z)}`;
        if (id === 0) {
            this.blocks.delete(key);
        } else {
            this.blocks.set(key, id);
        }
        
        if (updateMesh) {
            this.rebuildMesh();
        }
    }

    getBlock(x, y, z) {
        return this.blocks.get(`${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`) || 0;
    }

    rebuildMesh() {
        // Rebuilds the InstancedMesh array (Basic implementation)
        // A true Minecraft clone uses chunked buffer geometries, but this gets the logic started.
        let count = 0;
        const matrix = new THREE.Matrix4();
        
        for (const [key, id] of this.blocks.entries()) {
            const [x, y, z] = key.split(',').map(Number);
            matrix.setPosition(x, y, z);
            this.instancedMesh.setMatrixAt(count++, matrix);
        }
        this.instancedMesh.count = count;
        this.instancedMesh.instanceMatrix.needsUpdate = true;
    }
}
